'use client';
import Link from 'next/link';
import { useLanguage } from '@/lib/LanguageContext';

const tiles = [
  { href: '/disease-detection', label: 'nav_disease', desc: 'Photograph a leaf — get a likely diagnosis and treatment options.', icon: '🌿' },
  { href: '/weather', label: 'nav_weather', desc: 'Local forecast plus a plain-language irrigation call for today.', icon: '🌦️' },
  { href: '/fertilizer', label: 'nav_fertilizer', desc: 'Stage-by-stage NPK guidance for your crop.', icon: '🧪' },
  { href: '/crop-calendar', label: 'nav_calendar', desc: 'Sowing and harvest windows for major Kharif, Rabi and Zaid crops.', icon: '📅' },
  { href: '/market-prices', label: 'nav_market', desc: 'Latest mandi prices to help you decide when and where to sell.', icon: '📈' },
  { href: '/schemes', label: 'nav_schemes', desc: 'Central government schemes you may be eligible for.', icon: '🏛️' },
  { href: '/chatbot', label: 'nav_chat', desc: 'Ask a question in Tamil, Hindi or English — anytime.', icon: '💬' }
];

export default function Home() {
  const { t } = useLanguage();
  return (
    <div>
      <section className="ledger-card mt-6 p-6 md:p-8">
        <p className="stamp text-gold text-xs inline-block mb-3">🌾 · FIELD LEDGER</p>
        <h1 className="font-display text-3xl md:text-4xl font-semibold text-field leading-tight">
          {t('appName')}
        </h1>
        <p className="text-soil mt-2 max-w-xl">{t('tagline')}</p>
      </section>

      <section className="grid sm:grid-cols-2 gap-4 mt-6">
        {tiles.map((tile) => (
          <Link
            key={tile.href}
            href={tile.href}
            className="ledger-card p-5 hover:border-gold transition-colors group"
          >
            <div className="text-2xl">{tile.icon}</div>
            <h2 className="font-display text-lg font-semibold text-field mt-2 group-hover:text-gold">
              {t(tile.label)}
            </h2>
            <p className="text-sm text-soil/80 mt-1">{tile.desc}</p>
          </Link>
        ))}
      </section>
    </div>
  );
}
