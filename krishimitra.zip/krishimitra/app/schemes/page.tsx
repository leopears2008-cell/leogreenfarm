import { schemes } from '@/lib/schemes';

export default function SchemesPage() {
  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">Government Schemes</h1>
      <p className="text-sm text-soil/70 mt-1">Curated list of major central schemes. Confirm current terms on the official portal before applying.</p>

      <div className="space-y-4 mt-4">
        {schemes.map((s) => (
          <div key={s.name} className="ledger-card p-5">
            <h2 className="font-display text-lg font-semibold text-field">{s.name}</h2>
            <p className="text-sm text-soil/80 mt-1">{s.summary}</p>
            <dl className="grid sm:grid-cols-2 gap-3 mt-3 text-sm">
              <div>
                <dt className="text-xs uppercase font-mono text-soil/50">Benefit</dt>
                <dd className="text-field/90">{s.benefit}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase font-mono text-soil/50">Eligibility</dt>
                <dd className="text-field/90">{s.eligibility}</dd>
              </div>
            </dl>
            <a href={s.link} target="_blank" rel="noopener noreferrer" className="inline-block mt-3 text-sm text-gold font-semibold hover:underline">
              Official portal ↗
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}
