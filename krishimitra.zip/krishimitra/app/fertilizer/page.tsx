'use client';
import { useState } from 'react';
import { useLanguage } from '@/lib/LanguageContext';
import { cropCalendar, getFertilizerPlan } from '@/lib/cropData';

export default function FertilizerPage() {
  const { t } = useLanguage();
  const [crop, setCrop] = useState(cropCalendar[0].crop);
  const plan = getFertilizerPlan(crop);

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">{t('nav_fertilizer')}</h1>

      <div className="ledger-card p-5 mt-4">
        <label className="text-sm">
          <span className="block text-soil/70 mb-1">Select crop</span>
          <select
            value={crop}
            onChange={(e) => setCrop(e.target.value)}
            className="border border-soil/30 rounded px-3 py-2 bg-white w-full sm:w-64"
          >
            {cropCalendar.map((c) => (
              <option key={c.crop} value={c.crop}>{c.crop}</option>
            ))}
          </select>
        </label>
      </div>

      <div className="mt-4 relative">
        <div className="absolute left-4 top-2 bottom-2 w-px bg-soil/20" aria-hidden />
        <div className="space-y-4">
          {plan.map((stage, i) => (
            <div key={stage.stage} className="ledger-card p-4 pl-10 relative">
              <span className="absolute left-2 top-4 w-4 h-4 rounded-full bg-gold border-2 border-husk" />
              <p className="text-xs font-mono text-soil/60">STAGE {i + 1}</p>
              <h2 className="font-display text-lg font-semibold text-field">{stage.stage}</h2>
              <p className="text-sm text-field/90 mt-1">{stage.npkAdvice}</p>
              <p className="text-xs text-soil/60 mt-1 italic">{stage.note}</p>
            </div>
          ))}
        </div>
      </div>

      <p className="text-xs text-soil/60 mt-4">
        General baseline guidance per acre. Adjust using your Soil Health Card results where available — see the Govt. Schemes page.
      </p>
    </div>
  );
}
