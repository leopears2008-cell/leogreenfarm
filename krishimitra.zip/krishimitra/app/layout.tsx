import type { Metadata } from 'next';
import { Fraunces, Work_Sans, IBM_Plex_Mono } from 'next/font/google';
import './globals.css';
import Nav from '@/components/Nav';
import { LanguageProvider } from '@/lib/LanguageContext';

const fraunces = Fraunces({ subsets: ['latin'], variable: '--font-fraunces', weight: ['500', '600', '700'] });
const worksans = Work_Sans({ subsets: ['latin'], variable: '--font-worksans', weight: ['400', '500', '600'] });
const plexmono = IBM_Plex_Mono({ subsets: ['latin'], variable: '--font-plexmono', weight: ['400', '500'] });

export const metadata: Metadata = {
  title: 'KrishiMitra — Farmer Advisory',
  description: 'AI-powered crop disease detection, weather, irrigation, fertilizer and market guidance for farmers'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${fraunces.variable} ${worksans.variable} ${plexmono.variable} font-body`}>
        <LanguageProvider>
          <Nav />
          <main className="max-w-5xl mx-auto px-4 pb-24">{children}</main>
        </LanguageProvider>
      </body>
    </html>
  );
}
