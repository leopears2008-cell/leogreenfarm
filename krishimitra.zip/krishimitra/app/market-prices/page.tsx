'use client';
import { useEffect, useState } from 'react';
import { useLanguage } from '@/lib/LanguageContext';

type Price = {
  commodity: string;
  mandi: string;
  minPrice: number;
  maxPrice: number;
  modalPrice: number;
  unit: string;
  date: string;
};

export default function MarketPricesPage() {
  const { t } = useLanguage();
  const [prices, setPrices] = useState<Price[]>([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPrices();
  }, []);

  async function fetchPrices() {
    setLoading(true);
    const res = await fetch(`/api/market-prices${q ? `?q=${encodeURIComponent(q)}` : ''}`);
    const data = await res.json();
    setPrices(data.prices ?? []);
    setLoading(false);
  }

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">{t('nav_market')}</h1>

      <div className="ledger-card p-4 mt-4 flex gap-3 flex-wrap items-end">
        <label className="text-sm flex-1 min-w-[180px]">
          <span className="block text-soil/70 mb-1">Search commodity</span>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchPrices()}
            placeholder="e.g. Wheat"
            className="border border-soil/30 rounded px-3 py-2 w-full"
          />
        </label>
        <button onClick={fetchPrices} className="px-4 py-2 rounded bg-gold text-field font-medium text-sm">
          Search
        </button>
      </div>

      <div className="ledger-card mt-4 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-soil/60 text-xs uppercase font-mono border-b border-soil/15">
              <th className="p-3">Commodity</th>
              <th className="p-3">Mandi</th>
              <th className="p-3 text-right">Min</th>
              <th className="p-3 text-right">Modal</th>
              <th className="p-3 text-right">Max</th>
              <th className="p-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} className="p-4 text-center text-soil/50">Loading…</td></tr>
            ) : prices.length === 0 ? (
              <tr><td colSpan={6} className="p-4 text-center text-soil/50">No results.</td></tr>
            ) : (
              prices.map((p, i) => (
                <tr key={i} className="border-b border-soil/10 last:border-b-0">
                  <td className="p-3 font-medium text-field">{p.commodity}</td>
                  <td className="p-3 text-soil/80">{p.mandi}</td>
                  <td className="p-3 text-right font-mono">{p.minPrice}</td>
                  <td className="p-3 text-right font-mono font-semibold text-gold">{p.modalPrice}</td>
                  <td className="p-3 text-right font-mono">{p.maxPrice}</td>
                  <td className="p-3 text-soil/60">{p.date}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <p className="text-xs text-soil/60 mt-3">
        Prices in ₹/quintal. Demo data — connect the Agmarknet/data.gov.in API in <code className="font-mono">app/api/market-prices/route.ts</code> for live data.
      </p>
    </div>
  );
}
