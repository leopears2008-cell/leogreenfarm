import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

export const runtime = 'nodejs';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const langNames: Record<string, string> = { en: 'English', hi: 'Hindi (हिंदी)', ta: 'Tamil (தமிழ்)' };

export async function POST(req: NextRequest) {
  try {
    if (!process.env.ANTHROPIC_API_KEY) {
      return NextResponse.json({ error: 'Server is missing ANTHROPIC_API_KEY. Add it to your .env.local file.' }, { status: 500 });
    }

    const { messages, lang } = await req.json();
    if (!Array.isArray(messages)) {
      return NextResponse.json({ error: 'messages array is required' }, { status: 400 });
    }

    const system = `You are KrishiMitra, a friendly farm-advisory assistant for Indian smallholder farmers.
Reply in ${langNames[lang] ?? 'English'} only, in plain conversational language a farmer with no formal agri-science background can follow.
Cover crops, pests/disease, weather-linked farming decisions, irrigation, fertilizer, market prices and government schemes.
Keep answers short: 3-6 sentences or a short bullet list. If a question needs local specifics you don't have (exact soil test, exact mandi rate), say so and suggest who to ask locally.
If asked something unrelated to farming, gently redirect to farming topics.`;

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      system,
      messages: messages.map((m: { role: string; content: string }) => ({ role: m.role, content: m.content }))
    });

    const textBlock = response.content.find((b) => b.type === 'text');
    const reply = textBlock && 'text' in textBlock ? textBlock.text : '';

    return NextResponse.json({ reply });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Unknown error' }, { status: 500 });
  }
}
