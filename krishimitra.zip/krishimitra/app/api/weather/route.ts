import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

// Open-Meteo is free and requires no API key.
const FORECAST_URL = 'https://api.open-meteo.com/v1/forecast';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const lat = searchParams.get('lat');
  const lon = searchParams.get('lon');
  const waterNeed = (searchParams.get('waterNeed') as 'Low' | 'Medium' | 'High') ?? 'Medium';

  if (!lat || !lon) {
    return NextResponse.json({ error: 'lat and lon query params are required' }, { status: 400 });
  }

  const url = new URL(FORECAST_URL);
  url.searchParams.set('latitude', lat);
  url.searchParams.set('longitude', lon);
  url.searchParams.set('daily', 'temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,et0_fao_evapotranspiration');
  url.searchParams.set('current', 'temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m');
  url.searchParams.set('timezone', 'auto');
  url.searchParams.set('forecast_days', '7');

  try {
    const res = await fetch(url.toString());
    if (!res.ok) throw new Error(`Weather provider returned ${res.status}`);
    const data = await res.json();

    const irrigation = buildIrrigationAdvice(data, waterNeed);

    return NextResponse.json({ ...data, irrigation });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Failed to fetch weather' }, { status: 500 });
  }
}

function buildIrrigationAdvice(data: any, waterNeed: 'Low' | 'Medium' | 'High') {
  const rainNext3 = (data?.daily?.precipitation_sum ?? []).slice(0, 3).reduce((a: number, b: number) => a + b, 0);
  const rainProbTomorrow = data?.daily?.precipitation_probability_max?.[1] ?? 0;
  const et0Next3 = (data?.daily?.et0_fao_evapotranspiration ?? []).slice(0, 3).reduce((a: number, b: number) => a + b, 0);

  const waterFactor = waterNeed === 'High' ? 1.3 : waterNeed === 'Low' ? 0.7 : 1;
  const deficitMm = et0Next3 * waterFactor - rainNext3;

  let action: 'skip' | 'light' | 'irrigate' = 'light';
  let reason = '';

  if (rainProbTomorrow >= 60 && rainNext3 >= 10) {
    action = 'skip';
    reason = `Rain expected soon (${rainNext3.toFixed(0)}mm over next 3 days, ${rainProbTomorrow}% chance tomorrow) — hold off on irrigation.`;
  } else if (deficitMm > 15) {
    action = 'irrigate';
    reason = `Crop water demand (${et0Next3.toFixed(0)}mm over 3 days) far exceeds expected rainfall (${rainNext3.toFixed(0)}mm) — irrigate soon.`;
  } else if (deficitMm > 5) {
    action = 'light';
    reason = `Moderate deficit expected (${deficitMm.toFixed(0)}mm) — a light irrigation this week should be enough.`;
  } else {
    action = 'skip';
    reason = `Expected rainfall (${rainNext3.toFixed(0)}mm) roughly matches crop water demand — no irrigation needed right now.`;
  }

  return { action, reason, rainNext3mm: Math.round(rainNext3), et0Next3mm: Math.round(et0Next3) };
}
