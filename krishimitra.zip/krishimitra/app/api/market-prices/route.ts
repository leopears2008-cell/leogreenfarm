import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

// Sample/mock mandi price data so the UI works out of the box.
// To go live, swap this handler to call data.gov.in's Agmarknet API, e.g.:
// https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070?api-key=YOUR_KEY&format=json&filters[commodity]=...
// (Free API key from https://data.gov.in)

const MOCK_PRICES = [
  { commodity: 'Wheat', mandi: 'Karnal, Haryana', minPrice: 2180, maxPrice: 2260, modalPrice: 2220, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Rice (Paddy - Common)', mandi: 'Kurnool, Andhra Pradesh', minPrice: 2020, maxPrice: 2150, modalPrice: 2090, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Cotton', mandi: 'Rajkot, Gujarat', minPrice: 7100, maxPrice: 7450, modalPrice: 7300, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Sugarcane', mandi: 'Meerut, Uttar Pradesh', minPrice: 350, maxPrice: 380, modalPrice: 365, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Groundnut', mandi: 'Junagadh, Gujarat', minPrice: 5800, maxPrice: 6150, modalPrice: 5980, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Mustard', mandi: 'Alwar, Rajasthan', minPrice: 5300, maxPrice: 5550, modalPrice: 5420, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Gram (Chana)', mandi: 'Indore, Madhya Pradesh', minPrice: 5100, maxPrice: 5400, modalPrice: 5250, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Maize', mandi: 'Davangere, Karnataka', minPrice: 1950, maxPrice: 2100, modalPrice: 2020, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Onion', mandi: 'Lasalgaon, Maharashtra', minPrice: 1200, maxPrice: 1850, modalPrice: 1500, unit: '₹/quintal', date: '2026-07-10' },
  { commodity: 'Tomato', mandi: 'Kolar, Karnataka', minPrice: 800, maxPrice: 1400, modalPrice: 1100, unit: '₹/quintal', date: '2026-07-10' }
];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get('q')?.toLowerCase();
  const data = q ? MOCK_PRICES.filter((p) => p.commodity.toLowerCase().includes(q)) : MOCK_PRICES;
  return NextResponse.json({ source: 'mock', asOf: '2026-07-10', prices: data });
}
