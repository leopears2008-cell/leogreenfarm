# KrishiMitra — Farmer Advisory Platform (Foundation)

A Next.js 14 app covering the **farmer advisory** half of the brief:

- 🌿 AI crop disease detection from photos (Claude vision)
- 🌦️ Weather forecast + auto-generated irrigation advice (Open-Meteo, free, no key)
- 🧪 Fertilizer (NPK) suggestions by crop and growth stage
- 📅 Crop calendar (Kharif / Rabi / Zaid sowing & harvest windows)
- 📈 Market price lookup (mock data, wired for a real mandi API)
- 🏛️ Government scheme info (PM-KISAN, PMFBY, KCC, Soil Health Card, e-NAM, PMKSY)
- 💬 Multilingual chatbot — English, Hindi, Tamil (Claude)

The **marketplace half** (buy/sell, cart, orders, payments, reviews) is not built yet — say the word and it slots in.

## 1. Install

```bash
npm install
```

## 2. Configure environment

```bash
cp .env.example .env.local
```

Add your Anthropic API key to `.env.local`:

```
ANTHROPIC_API_KEY=sk-ant-...
```

This powers **Disease Scan** and **Ask KrishiMitra**. Everything else (weather, calendar, fertilizer, schemes) works with no key.

## 3. Run

```bash
npm run dev
```

Open http://localhost:3000

## Where things live

| Feature | Page | API route | Data |
|---|---|---|---|
| Disease detection | `app/disease-detection/page.tsx` | `app/api/disease-detection/route.ts` | Claude vision, JSON |
| Weather + irrigation | `app/weather/page.tsx` | `app/api/weather/route.ts` | Open-Meteo forecast API |
| Fertilizer plan | `app/fertilizer/page.tsx` | — (client-side rules) | `lib/cropData.ts` |
| Crop calendar | `app/crop-calendar/page.tsx` | — (static) | `lib/cropData.ts` |
| Market prices | `app/market-prices/page.tsx` | `app/api/market-prices/route.ts` | Mock — swap for data.gov.in Agmarknet |
| Govt schemes | `app/schemes/page.tsx` | — (static) | `lib/schemes.ts` |
| Chatbot | `app/chatbot/page.tsx` | `app/api/chat/route.ts` | Claude, language-aware system prompt |

## Making it production-ready

1. **Market prices**: replace the mock handler in `app/api/market-prices/route.ts` with a call to the data.gov.in Agmarknet API.
2. **Fertilizer + crop calendar data**: currently generalized baselines. Swap in your state agricultural university (KVK) recommendations.
3. **Disease detection accuracy**: for higher accuracy at scale/offline use, consider pairing Claude vision with a dedicated plant-pathology model.
4. **Auth & farmer profiles**: add a database (Postgres via Prisma or Supabase) to persist farmer location, crop history, etc. — see `/prisma`.
5. **Push notifications**: weather/irrigation alerts and disease outbreak warnings work best as SMS/WhatsApp push.

## Next: the Marketplace module

When you're ready, the second half — direct farmer-to-consumer sales, buying seeds/fertilizer/equipment, order tracking — can be added.
