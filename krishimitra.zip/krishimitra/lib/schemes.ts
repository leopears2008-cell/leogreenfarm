export type Scheme = {
  name: string;
  summary: string;
  benefit: string;
  eligibility: string;
  link: string;
};

// Curated reference list of major central government schemes for farmers.
// Verify current terms on the official portals before advising — scheme rules change.
export const schemes: Scheme[] = [
  {
    name: 'PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)',
    summary: 'Direct income support paid straight to landholding farmer families.',
    benefit: '₹6,000 per year, paid in 3 instalments of ₹2,000 directly to bank account.',
    eligibility: 'Landholding farmer families, subject to exclusion criteria (institutional landholders, income-tax payers, etc.).',
    link: 'https://pmkisan.gov.in'
  },
  {
    name: 'PMFBY (Pradhan Mantri Fasal Bima Yojana)',
    summary: 'Crop insurance scheme covering yield losses from natural calamities, pests and disease.',
    benefit: 'Low premium (2% Kharif / 1.5% Rabi / 5% commercial-horticulture crops), rest subsidised by government.',
    eligibility: 'All farmers growing notified crops in notified areas, loanee and non-loanee both.',
    link: 'https://pmfby.gov.in'
  },
  {
    name: 'Kisan Credit Card (KCC)',
    summary: 'Short-term credit for crop production, post-harvest expenses and farm assets at low interest.',
    benefit: 'Collateral-free loans up to ₹1.6 lakh (higher with collateral); interest subvention brings effective rate down.',
    eligibility: 'Farmers, tenant farmers, oral lessees, sharecroppers, SHGs/JLGs of farmers.',
    link: 'https://www.myscheme.gov.in/schemes/kcc'
  },
  {
    name: 'Soil Health Card Scheme',
    summary: 'Free soil testing with crop-wise nutrient and fertilizer recommendations every 2 years.',
    benefit: 'Personalised soil nutrient status report + fertilizer/amendment advice for your field.',
    eligibility: 'All farmers — apply through local Krishi Vigyan Kendra (KVK) or agriculture department.',
    link: 'https://soilhealth.dac.gov.in'
  },
  {
    name: 'e-NAM (National Agriculture Market)',
    summary: 'Online trading platform connecting existing mandis for transparent, competitive price discovery.',
    benefit: 'Farmers can sell produce to buyers across the country, reducing dependence on local middlemen.',
    eligibility: 'Farmers registered with a participating APMC mandi.',
    link: 'https://enam.gov.in'
  },
  {
    name: 'PM Krishi Sinchayee Yojana (PMKSY)',
    summary: 'Support for irrigation infrastructure, including micro-irrigation (drip/sprinkler).',
    benefit: 'Subsidy of 55–80% on drip/sprinkler irrigation equipment depending on category and state.',
    eligibility: 'All farmer categories; small/marginal and SC/ST farmers get higher subsidy slabs.',
    link: 'https://pmksy.gov.in'
  }
];
