export type Lang = 'en' | 'hi' | 'ta';

// NOTE: The source PDF's Hindi/Tamil strings were corrupted during text extraction
// (non-Latin glyphs did not survive the PDF -> text conversion). The English keys
// below are reconstructed verbatim from the PDF; the hi/ta values are best-effort
// re-translations of the same UI strings — please have a native speaker review
// before shipping.

export const translations: Record<Lang, Record<string, string>> = {
  en: {
    appName: 'KrishiMitra',
    tagline: 'Your field, your data, your decisions.',
    nav_home: 'Home',
    nav_disease: 'Disease Scan',
    nav_weather: 'Weather & Irrigation',
    nav_fertilizer: 'Fertilizer',
    nav_calendar: 'Crop Calendar',
    nav_market: 'Market Prices',
    nav_schemes: 'Govt. Schemes',
    nav_chat: 'Ask KrishiMitra',
    upload_photo: 'Upload a leaf or crop photo',
    scan_now: 'Scan for disease',
    scanning: 'Analysing photo…',
    get_weather: 'Get weather for my location',
    ask_placeholder: 'Ask about your crop, pest, weather, or a scheme…',
    send: 'Send'
  },
  hi: {
    appName: 'कृषिमित्र',
    tagline: 'आपका खेत, आपका डेटा, आपके फैसले।',
    nav_home: 'मुख्य पृष्ठ',
    nav_disease: 'रोग जांच',
    nav_weather: 'मौसम और सिंचाई',
    nav_fertilizer: 'उर्वरक',
    nav_calendar: 'फसल कैलेंडर',
    nav_market: 'मंडी भाव',
    nav_schemes: 'सरकारी योजनाएं',
    nav_chat: 'कृषिमित्र से पूछें',
    upload_photo: 'पत्ती या फसल की फोटो अपलोड करें',
    scan_now: 'रोग की जांच करें',
    scanning: 'फोटो का विश्लेषण हो रहा है…',
    get_weather: 'मेरे स्थान का मौसम देखें',
    ask_placeholder: 'फसल, कीट, मौसम या योजना के बारे में पूछें…',
    send: 'भेजें'
  },
  ta: {
    appName: 'கிருஷிமித்ரா',
    tagline: 'உங்கள் வயல், உங்கள் தரவு, உங்கள் முடிவுகள்.',
    nav_home: 'முகப்பு',
    nav_disease: 'நோய் கண்டறிதல்',
    nav_weather: 'வானிலை & பாசனம்',
    nav_fertilizer: 'உரம்',
    nav_calendar: 'பயிர் காலண்டர்',
    nav_market: 'சந்தை விலைகள்',
    nav_schemes: 'அரசு திட்டங்கள்',
    nav_chat: 'கிருஷிமித்ராவிடம் கேளுங்கள்',
    upload_photo: 'இலை அல்லது பயிர் புகைப்படத்தை பதிவேற்றவும்',
    scan_now: 'நோய் கண்டறிதல் தொடங்கு',
    scanning: 'புகைப்படம் பகுப்பாய்வு செய்யப்படுகிறது…',
    get_weather: 'எனது இருப்பிடத்தின் வானிலை பெறவும்',
    ask_placeholder: 'பயிர், பூச்சி, வானிலை அல்லது திட்டம் பற்றி கேளுங்கள்…',
    send: 'அனுப்பு'
  }
};

export function t(lang: Lang, key: string): string {
  return translations[lang]?.[key] ?? translations.en[key] ?? key;
}
