import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        field: '#1F3A2E', // deep field green - primary
        gold: '#C98A2C',  // harvest gold - accent / CTA
        husk: '#F6F1E4',  // husk cream - background
        soil: '#5C4433',  // soil brown - secondary text/borders
        sky: '#6FA8C4'    // sky wash - weather/water accent
      },
      fontFamily: {
        display: ['var(--font-fraunces)', 'Georgia', 'serif'],
        body: ['var(--font-worksans)', 'Noto Sans', 'Noto Sans Tamil', 'Noto Sans Devanagari', 'sans-serif'],
        mono: ['var(--font-plexmono)', 'ui-monospace', 'monospace']
      },
      backgroundImage: {
        ledger: 'repeating-linear-gradient(to bottom, transparent, transparent 27px, rgba(92,68,51,0.12) 28px)'
      }
    }
  },
  plugins: []
};

export default config;
