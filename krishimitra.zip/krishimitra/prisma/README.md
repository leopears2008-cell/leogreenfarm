# prisma/

No Prisma schema was included in the original codebase — the app currently has no database
(farmer profiles, auth, and order history are not persisted). This folder is a placeholder
for when that's added, per the README's "Making it production-ready" step 4.

Suggested starting point once you add Prisma:

```bash
npm install prisma @prisma/client
npx prisma init
```

Then define a `schema.prisma` here with models for `Farmer`, `CropHistory`, `DiseaseScan`, etc.,
and point `DATABASE_URL` at Postgres/Supabase in `.env.local`.
