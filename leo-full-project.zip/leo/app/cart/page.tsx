'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';

export default function CartPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [items, setItems] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if (status === 'authenticated') fetchCart();
  }, [status]);

  async function fetchCart() {
    setLoading(true);
    const res = await fetch('/api/cart');
    const data = await res.json();
    setItems(data.items ?? []);
    setTotal(data.total ?? 0);
    setLoading(false);
  }

  async function updateQty(productId: string, quantity: number) {
    await fetch('/api/cart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, quantity })
    });
    fetchCart();
  }

  if (loading) return <p className="mt-6 text-soil/50 text-sm">Loading…</p>;

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">Your cart</h1>
      {items.length === 0 ? (
        <p className="text-sm text-soil/60 mt-4">Your cart is empty. <a href="/marketplace" className="text-gold hover:underline">Browse the marketplace</a>.</p>
      ) : (
        <>
          <div className="space-y-3 mt-4">
            {items.map((item) => (
              <div key={item.id} className="ledger-card p-4 flex items-center justify-between gap-3">
                <div>
                  <p className="font-medium text-field">{item.product.title}</p>
                  <p className="text-xs text-soil/60">₹{(item.product.price / 100).toFixed(2)} / {item.product.unit}</p>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={0}
                    max={item.product.stock}
                    value={item.quantity}
                    onChange={(e) => updateQty(item.productId, Number(e.target.value))}
                    className="border border-soil/30 rounded px-2 py-1 w-16 text-sm"
                  />
                  <button onClick={() => updateQty(item.productId, 0)} className="text-xs text-red-600 hover:underline">
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="ledger-card p-4 mt-4 flex items-center justify-between">
            <p className="font-semibold text-field">Total</p>
            <p className="font-mono text-xl text-gold">₹{(total / 100).toFixed(2)}</p>
          </div>
          <a
            href="/checkout"
            className="block text-center mt-4 px-4 py-3 rounded bg-gold text-field font-medium"
          >
            Proceed to checkout
          </a>
        </>
      )}
    </div>
  );
}
