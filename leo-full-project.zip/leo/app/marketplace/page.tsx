'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';

type Product = {
  id: string;
  title: string;
  category: string;
  price: number;
  unit: string;
  stock: number;
  imageUrl?: string;
  seller: { name: string };
};

export default function MarketplacePage() {
  const { data: session } = useSession();
  const [products, setProducts] = useState<Product[]>([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);
  const [addingId, setAddingId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  async function fetchProducts() {
    setLoading(true);
    const res = await fetch(`/api/products${q ? `?q=${encodeURIComponent(q)}` : ''}`);
    const data = await res.json();
    setProducts(data.products ?? []);
    setLoading(false);
  }

  async function addToCart(productId: string) {
    if (!session) {
      window.location.href = '/login';
      return;
    }
    setAddingId(productId);
    const res = await fetch('/api/cart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, quantity: 1 })
    });
    const data = await res.json();
    setAddingId(null);
    setToast(res.ok ? 'Added to cart' : data.error ?? 'Could not add to cart');
    setTimeout(() => setToast(null), 2000);
  }

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="font-display text-2xl font-semibold text-field">Marketplace</h1>
        {session && ['FARMER', 'ADMIN'].includes((session.user as any).role) && (
          <Link href="/marketplace/sell" className="px-4 py-2 rounded bg-gold text-field text-sm font-medium">
            + List a product
          </Link>
        )}
      </div>

      <div className="ledger-card p-4 mt-4 flex gap-3 flex-wrap items-end">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && fetchProducts()}
          placeholder="Search products…"
          className="border border-soil/30 rounded px-3 py-2 flex-1 min-w-[180px]"
        />
        <button onClick={fetchProducts} className="px-4 py-2 rounded bg-field text-husk text-sm">
          Search
        </button>
      </div>

      {toast && <div className="mt-3 text-sm text-field bg-gold/20 border border-gold rounded px-3 py-2">{toast}</div>}

      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
        {loading ? (
          <p className="text-soil/50 text-sm">Loading…</p>
        ) : products.length === 0 ? (
          <p className="text-soil/50 text-sm">No products found.</p>
        ) : (
          products.map((p) => (
            <div key={p.id} className="ledger-card p-4 flex flex-col">
              <Link href={`/marketplace/${p.id}`}>
                {p.imageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={p.imageUrl} alt={p.title} className="w-full h-36 object-cover rounded" />
                ) : (
                  <div className="w-full h-36 bg-husk border border-soil/10 rounded flex items-center justify-center text-soil/40 text-sm">
                    No image
                  </div>
                )}
                <h2 className="font-display text-lg font-semibold text-field mt-2">{p.title}</h2>
              </Link>
              <p className="text-xs text-soil/60">{p.category} · sold by {p.seller.name}</p>
              <p className="font-mono text-lg text-gold mt-1">
                ₹{(p.price / 100).toFixed(2)} <span className="text-xs text-soil/60">/ {p.unit}</span>
              </p>
              <p className="text-xs text-soil/50">{p.stock > 0 ? `${p.stock} in stock` : 'Out of stock'}</p>
              <button
                onClick={() => addToCart(p.id)}
                disabled={addingId === p.id || p.stock === 0}
                className="mt-3 px-3 py-2 rounded bg-field text-husk text-sm disabled:opacity-40"
              >
                {addingId === p.id ? 'Adding…' : 'Add to cart'}
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
