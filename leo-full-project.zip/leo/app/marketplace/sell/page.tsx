'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import ImageUploader from '@/components/marketplace/ImageUploader';

const categories = ['Seeds', 'Fertilizer', 'Produce (Grains)', 'Produce (Vegetables)', 'Produce (Fruits)', 'Equipment', 'Other'];

export default function SellPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [form, setForm] = useState({
    title: '',
    description: '',
    category: categories[0],
    price: '',
    unit: 'kg',
    stock: ''
  });
  const [image, setImage] = useState<{ url: string; publicId: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (status === 'loading') return null;
  if (!session) {
    router.push('/login');
    return null;
  }
  if (!['FARMER', 'ADMIN'].includes((session.user as any).role)) {
    return <p className="mt-6 text-sm text-soil/60">Only farmer accounts can list products.</p>;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          price: Math.round(Number(form.price) * 100), // rupees -> paise
          stock: Number(form.stock),
          imageUrl: image?.url,
          imagePublicId: image?.publicId
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Could not list product');
      router.push(`/marketplace/${data.id}`);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-6 max-w-lg">
      <h1 className="font-display text-2xl font-semibold text-field">List a product</h1>
      <form onSubmit={handleSubmit} className="ledger-card p-6 mt-4 space-y-4">
        <label className="text-sm block">
          <span className="block text-soil/70 mb-1">Title</span>
          <input
            required
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="border border-soil/30 rounded px-3 py-2 w-full"
          />
        </label>
        <label className="text-sm block">
          <span className="block text-soil/70 mb-1">Description</span>
          <textarea
            required
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="border border-soil/30 rounded px-3 py-2 w-full h-24"
          />
        </label>
        <label className="text-sm block">
          <span className="block text-soil/70 mb-1">Category</span>
          <select
            value={form.category}
            onChange={(e) => setForm({ ...form, category: e.target.value })}
            className="border border-soil/30 rounded px-3 py-2 w-full bg-white"
          >
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </label>
        <div className="flex gap-3">
          <label className="text-sm block flex-1">
            <span className="block text-soil/70 mb-1">Price (₹)</span>
            <input
              required
              type="number"
              min={0}
              step="0.01"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              className="border border-soil/30 rounded px-3 py-2 w-full"
            />
          </label>
          <label className="text-sm block w-28">
            <span className="block text-soil/70 mb-1">Unit</span>
            <input
              value={form.unit}
              onChange={(e) => setForm({ ...form, unit: e.target.value })}
              className="border border-soil/30 rounded px-3 py-2 w-full"
            />
          </label>
          <label className="text-sm block w-28">
            <span className="block text-soil/70 mb-1">Stock</span>
            <input
              required
              type="number"
              min={0}
              value={form.stock}
              onChange={(e) => setForm({ ...form, stock: e.target.value })}
              className="border border-soil/30 rounded px-3 py-2 w-full"
            />
          </label>
        </div>
        <div>
          <span className="block text-sm text-soil/70 mb-1">Photo</span>
          <ImageUploader onUploaded={(url, publicId) => setImage({ url, publicId })} />
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full px-4 py-2 rounded bg-gold text-field font-medium disabled:opacity-40"
        >
          {loading ? 'Listing…' : 'List product'}
        </button>
      </form>
    </div>
  );
}
