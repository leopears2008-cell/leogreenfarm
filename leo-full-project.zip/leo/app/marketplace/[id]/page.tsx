'use client';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { data: session } = useSession();
  const router = useRouter();
  const [product, setProduct] = useState<any>(null);
  const [qty, setQty] = useState(1);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/products/${id}`)
      .then((r) => r.json())
      .then(setProduct)
      .finally(() => setLoading(false));
  }, [id]);

  async function addToCart() {
    if (!session) {
      router.push('/login');
      return;
    }
    const res = await fetch('/api/cart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId: id, quantity: qty })
    });
    const data = await res.json();
    setMessage(res.ok ? 'Added to cart.' : data.error);
  }

  if (loading) return <p className="mt-6 text-soil/50 text-sm">Loading…</p>;
  if (!product || product.error) return <p className="mt-6 text-soil/50 text-sm">Product not found.</p>;

  return (
    <div className="mt-6 grid md:grid-cols-2 gap-6">
      <div>
        {product.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={product.imageUrl} alt={product.title} className="w-full rounded-lg border border-soil/15" />
        ) : (
          <div className="w-full h-64 bg-husk border border-soil/10 rounded flex items-center justify-center text-soil/40">
            No image
          </div>
        )}
      </div>
      <div>
        <h1 className="font-display text-2xl font-semibold text-field">{product.title}</h1>
        <p className="text-sm text-soil/60 mt-1">{product.category} · sold by {product.seller.name}</p>
        <p className="font-mono text-2xl text-gold mt-3">
          ₹{(product.price / 100).toFixed(2)} <span className="text-sm text-soil/60">/ {product.unit}</span>
        </p>
        <p className="text-sm text-field/90 mt-3">{product.description}</p>
        <p className="text-xs text-soil/50 mt-2">{product.stock > 0 ? `${product.stock} ${product.unit} in stock` : 'Out of stock'}</p>

        <div className="flex items-center gap-3 mt-4">
          <input
            type="number"
            min={1}
            max={product.stock}
            value={qty}
            onChange={(e) => setQty(Number(e.target.value))}
            className="border border-soil/30 rounded px-3 py-2 w-20"
          />
          <button
            onClick={addToCart}
            disabled={product.stock === 0}
            className="px-4 py-2 rounded bg-gold text-field font-medium disabled:opacity-40"
          >
            Add to cart
          </button>
        </div>
        {message && <p className="text-sm text-soil/70 mt-2">{message}</p>}

        {product.reviews?.length > 0 && (
          <div className="mt-6">
            <h2 className="font-semibold text-soil text-sm">Reviews</h2>
            <div className="space-y-2 mt-2">
              {product.reviews.map((r: any) => (
                <div key={r.id} className="ledger-card p-3 text-sm">
                  <p className="font-medium text-field">{r.user.name} · {r.rating}★</p>
                  {r.comment && <p className="text-soil/80 mt-1">{r.comment}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
