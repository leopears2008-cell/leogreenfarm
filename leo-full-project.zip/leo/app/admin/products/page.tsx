'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';

export default function AdminProductsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if (status === 'authenticated' && (session?.user as any).role !== 'ADMIN') router.push('/');
    if (status === 'authenticated' && (session?.user as any).role === 'ADMIN') fetchProducts();
  }, [status, session]);

  async function fetchProducts() {
    setLoading(true);
    const res = await fetch('/api/products');
    const data = await res.json();
    setProducts(data.products ?? []);
    setLoading(false);
  }

  async function toggleActive(id: string, active: boolean) {
    await fetch(`/api/products/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: !active })
    });
    fetchProducts();
  }

  async function remove(id: string) {
    if (!confirm('Delete this product?')) return;
    await fetch(`/api/products/${id}`, { method: 'DELETE' });
    fetchProducts();
  }

  if (loading) return <p className="mt-6 text-soil/50 text-sm">Loading…</p>;

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">All products</h1>
      <div className="space-y-3 mt-4">
        {products.map((p) => (
          <div key={p.id} className="ledger-card p-4 flex items-center justify-between flex-wrap gap-3">
            <div>
              <p className="font-medium text-field">{p.title}</p>
              <p className="text-xs text-soil/60">
                {p.category} · ₹{(p.price / 100).toFixed(2)} / {p.unit} · {p.stock} in stock · seller: {p.seller.name}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => toggleActive(p.id, p.active)}
                className="px-3 py-1 rounded border border-soil/30 text-xs"
              >
                {p.active ? 'Deactivate' : 'Activate'}
              </button>
              <button onClick={() => remove(p.id)} className="px-3 py-1 rounded border border-red-400 text-red-600 text-xs">
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
