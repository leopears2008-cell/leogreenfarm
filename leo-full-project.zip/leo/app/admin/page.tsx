'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';

export default function AdminHome() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [stats, setStats] = useState<{ orders: number; revenue: number; products: number } | null>(null);

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if (status === 'authenticated' && (session?.user as any).role !== 'ADMIN') router.push('/');
    if (status === 'authenticated' && (session?.user as any).role === 'ADMIN') {
      Promise.all([
        fetch('/api/orders?all=1').then((r) => r.json()),
        fetch('/api/products').then((r) => r.json())
      ]).then(([ordersData, productsData]) => {
        const orders = ordersData.orders ?? [];
        const revenue = orders
          .filter((o: any) => o.status !== 'CANCELLED' && o.status !== 'PENDING')
          .reduce((s: number, o: any) => s + o.totalAmount, 0);
        setStats({ orders: orders.length, revenue, products: (productsData.products ?? []).length });
      });
    }
  }, [status, session]);

  if (!stats) return <p className="mt-6 text-soil/50 text-sm">Loading…</p>;

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">Admin dashboard</h1>
      <div className="grid sm:grid-cols-3 gap-4 mt-4">
        <div className="ledger-card p-5">
          <p className="text-xs text-soil/60 uppercase font-mono">Total orders</p>
          <p className="font-display text-3xl text-field mt-1">{stats.orders}</p>
        </div>
        <div className="ledger-card p-5">
          <p className="text-xs text-soil/60 uppercase font-mono">Revenue (paid+)</p>
          <p className="font-display text-3xl text-gold mt-1">₹{(stats.revenue / 100).toFixed(2)}</p>
        </div>
        <div className="ledger-card p-5">
          <p className="text-xs text-soil/60 uppercase font-mono">Listed products</p>
          <p className="font-display text-3xl text-field mt-1">{stats.products}</p>
        </div>
      </div>
      <div className="flex gap-4 mt-6">
        <Link href="/admin/orders" className="px-4 py-2 rounded bg-field text-husk text-sm">Manage orders</Link>
        <Link href="/admin/products" className="px-4 py-2 rounded bg-field text-husk text-sm">Manage products</Link>
      </div>
    </div>
  );
}
