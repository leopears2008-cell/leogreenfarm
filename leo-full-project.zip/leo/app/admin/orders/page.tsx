'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';

const statuses = ['PENDING', 'PAID', 'SHIPPED', 'DELIVERED', 'CANCELLED'];

export default function AdminOrdersPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if (status === 'authenticated' && (session?.user as any).role !== 'ADMIN') router.push('/');
    if (status === 'authenticated' && (session?.user as any).role === 'ADMIN') fetchOrders();
  }, [status, session]);

  async function fetchOrders() {
    setLoading(true);
    const res = await fetch('/api/orders?all=1');
    const data = await res.json();
    setOrders(data.orders ?? []);
    setLoading(false);
  }

  async function updateStatus(id: string, newStatus: string) {
    await fetch(`/api/admin/orders/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });
    fetchOrders();
  }

  if (loading) return <p className="mt-6 text-soil/50 text-sm">Loading…</p>;

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">All orders</h1>
      <div className="space-y-3 mt-4">
        {orders.map((o) => (
          <div key={o.id} className="ledger-card p-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <p className="font-mono text-sm text-soil/70">Order #{o.id.slice(-6)}</p>
                <p className="text-xs text-soil/60">{o.buyer.name} · {o.buyer.email}</p>
              </div>
              <select
                value={o.status}
                onChange={(e) => updateStatus(o.id, e.target.value)}
                className="border border-soil/30 rounded px-2 py-1 text-sm bg-white"
              >
                {statuses.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
            <p className="text-sm font-semibold text-field mt-2">₹{(o.totalAmount / 100).toFixed(2)}</p>
            <p className="text-xs text-soil/50">{o.shippingAddress}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
