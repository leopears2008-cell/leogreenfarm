'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { signIn } from 'next-auth/react';

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', role: 'FARMER' });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Registration failed');

      const signInRes = await signIn('credentials', {
        email: form.email,
        password: form.password,
        redirect: false
      });
      if (signInRes?.error) throw new Error('Registered, but sign-in failed. Try logging in.');

      router.push('/marketplace');
      router.refresh();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-10 max-w-md mx-auto">
      <h1 className="font-display text-2xl font-semibold text-field">Create your account</h1>
      <form onSubmit={handleSubmit} className="ledger-card p-6 mt-4 space-y-4">
        <Field label="Full name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
        <Field label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} required />
        <Field label="Phone (for order updates)" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} placeholder="+91..." />
        <Field label="Password" type="password" value={form.password} onChange={(v) => setForm({ ...form, password: v })} required />
        <label className="text-sm block">
          <span className="block text-soil/70 mb-1">I am a</span>
          <select
            value={form.role}
            onChange={(e) => setForm({ ...form, role: e.target.value })}
            className="border border-soil/30 rounded px-3 py-2 w-full bg-white"
          >
            <option value="FARMER">Farmer (I want to sell produce)</option>
            <option value="BUYER">Buyer (I want to purchase produce)</option>
          </select>
        </label>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full px-4 py-2 rounded bg-gold text-field font-medium disabled:opacity-40"
        >
          {loading ? 'Creating account…' : 'Create account'}
        </button>
        <p className="text-xs text-soil/60 text-center">
          Already have an account? <a href="/login" className="text-gold hover:underline">Sign in</a>
        </p>
      </form>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  required,
  placeholder
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="text-sm block">
      <span className="block text-soil/70 mb-1">{label}</span>
      <input
        type={type}
        value={value}
        required={required}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="border border-soil/30 rounded px-3 py-2 w-full"
      />
    </label>
  );
}
