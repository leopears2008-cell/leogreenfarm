'use client';
import { useState } from 'react';
import { useLanguage } from '@/lib/LanguageContext';
import { cropCalendar } from '@/lib/cropData';

const actionCopy: Record<string, { label: string; color: string }> = {
  skip: { label: 'Skip irrigation', color: 'bg-sky/20 text-sky border-sky' },
  light: { label: 'Light irrigation', color: 'bg-gold/20 text-gold border-gold' },
  irrigate: { label: 'Irrigate now', color: 'bg-red-100 text-red-700 border-red-400' }
};

export default function WeatherPage() {
  const { t } = useLanguage();
  const [crop, setCrop] = useState(cropCalendar[0].crop);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);

  function fetchWeather() {
    setLoading(true);
    setError(null);
    setData(null);
    const waterNeed = cropCalendar.find((c) => c.crop === crop)?.waterNeed ?? 'Medium';
    if (!navigator.geolocation) {
      setError('Location access is not available in this browser.');
      setLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          const res = await fetch(`/api/weather?lat=${latitude}&lon=${longitude}&waterNeed=${waterNeed}`);
          const json = await res.json();
          if (!res.ok) throw new Error(json.error ?? 'Could not load weather');
          setData(json);
        } catch (e: any) {
          setError(e.message);
        } finally {
          setLoading(false);
        }
      },
      () => {
        setError('Location permission denied. Enable location access and try again.');
        setLoading(false);
      }
    );
  }

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">{t('nav_weather')}</h1>
      <div className="ledger-card p-5 mt-4 flex flex-wrap items-end gap-3">
        <label className="text-sm">
          <span className="block text-soil/70 mb-1">Crop (for irrigation calc)</span>
          <select value={crop} onChange={(e) => setCrop(e.target.value)} className="border border-soil/30 rounded px-3 py-2 bg-white">
            {cropCalendar.map((c) => (
              <option key={c.crop} value={c.crop}>{c.crop}</option>
            ))}
          </select>
        </label>
        <button onClick={fetchWeather} disabled={loading} className="px-4 py-2 rounded bg-gold text-field font-medium disabled:opacity-40 text-sm">
          {loading ? 'Fetching…' : t('get_weather')}
        </button>
      </div>
      {error && <div className="ledger-card p-4 mt-4 border-red-400 text-red-700 text-sm">{error}</div>}
      {data && (
        <div className="grid md:grid-cols-2 gap-4 mt-4">
          <div className="ledger-card p-5">
            <h2 className="font-display text-lg font-semibold text-field mb-2">Current conditions</h2>
            <p className="font-mono text-3xl text-field">{data.current?.temperature_2m}°C</p>
            <p className="text-sm text-soil/70 mt-1">
              Humidity {data.current?.relative_humidity_2m}% · Wind {data.current?.wind_speed_10m} km/h
            </p>
            <h3 className="font-semibold text-soil text-sm mt-4">Next 7 days</h3>
            <div className="mt-2 space-y-1">
              {data.daily?.time?.map((day: string, i: number) => (
                <div key={day} className="flex justify-between text-sm border-b border-soil/10 py-1">
                  <span className="text-soil/70 font-mono">{new Date(day).toLocaleDateString(undefined, { weekday: 'short' })}</span>
                  <span>{data.daily.temperature_2m_min[i]}°–{data.daily.temperature_2m_max[i]}°C</span>
                  <span className="text-sky">{data.daily.precipitation_sum[i]}mm ({data.daily.precipitation_probability_max[i]}%)</span>
                </div>
              ))}
            </div>
          </div>
          <div className="ledger-card p-5">
            <h2 className="font-display text-lg font-semibold text-field mb-2">Irrigation recommendation</h2>
            <span className={`stamp text-xs border ${actionCopy[data.irrigation.action].color}`}>
              {actionCopy[data.irrigation.action].label}
            </span>
            <p className="text-sm text-field/90 mt-3">{data.irrigation.reason}</p>
            <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
              <div className="border border-soil/15 rounded p-2">
                <p className="text-soil/60 text-xs">Expected rain (3d)</p>
                <p className="font-mono text-lg">{data.irrigation.rainNext3mm}mm</p>
              </div>
              <div className="border border-soil/15 rounded p-2">
                <p className="text-soil/60 text-xs">Crop water demand (3d)</p>
                <p className="font-mono text-lg">{data.irrigation.et0Next3mm}mm</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
