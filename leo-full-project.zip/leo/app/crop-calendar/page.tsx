'use client';
import { useState } from 'react';
import { useLanguage } from '@/lib/LanguageContext';
import { cropCalendar, CropWindow } from '@/lib/cropData';

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const seasons: CropWindow['season'][] = ['Kharif', 'Rabi', 'Zaid'];

function barStyle(startMonth: number, span: number) {
  const left = ((startMonth - 1) / 12) * 100;
  const width = (span / 12) * 100;
  return { left: `${left}%`, width: `${width}%` };
}

export default function CropCalendarPage() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<'All' | CropWindow['season']>('All');
  const rows = cropCalendar.filter((c) => filter === 'All' || c.season === filter);

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">{t('nav_calendar')}</h1>
      <div className="flex gap-2 mt-4 flex-wrap">
        {(['All', ...seasons] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`stamp text-xs ${filter === s ? 'bg-field text-husk border-field' : 'text-soil border-soil/40'}`}
          >
            {s}
          </button>
        ))}
      </div>
      <div className="ledger-card mt-4 p-5 overflow-x-auto">
        <div className="min-w-[640px]">
          <div className="flex text-xs font-mono text-soil/60 pl-40">
            {months.map((m) => (
              <div key={m} className="flex-1 text-center">{m}</div>
            ))}
          </div>
          <div className="mt-2 bg-ledger">
            {rows.map((c) => (
              <div key={c.crop} className="flex items-center h-10 border-b border-soil/10 last:border-b-0">
                <div className="w-40 shrink-0 text-sm text-field font-medium truncate pr-2">{c.crop}</div>
                <div className="relative flex-1 h-6">
                  <div className="absolute h-2.5 top-0 bg-gold/70 rounded-sm" style={barStyle(c.sowMonth, c.sowSpan)} title={`Sowing: ${months[c.sowMonth - 1]}`} />
                  <div className="absolute h-2.5 bottom-0 bg-field/70 rounded-sm" style={barStyle(c.harvestMonth, c.harvestSpan)} title={`Harvest: ${months[c.harvestMonth - 1]}`} />
                </div>
              </div>
            ))}
          </div>
          <div className="flex gap-4 mt-3 text-xs text-soil/70">
            <span className="flex items-center gap-1"><span className="w-3 h-2.5 bg-gold/70 inline-block rounded-sm" /> Sowing</span>
            <span className="flex items-center gap-1"><span className="w-3 h-2.5 bg-field/70 inline-block rounded-sm" /> Harvest</span>
          </div>
        </div>
      </div>
      <p className="text-xs text-soil/60 mt-3">
        Windows are generalized for north/central India — shift by 2–4 weeks for your agro-climatic zone and irrigation access.
      </p>
    </div>
  );
}
