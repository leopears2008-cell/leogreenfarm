'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';

const statusColor: Record<string, string> = {
  PENDING: 'bg-gold/20 text-gold border-gold',
  PAID: 'bg-sky/20 text-sky border-sky',
  SHIPPED: 'bg-sky/20 text-sky border-sky',
  DELIVERED: 'bg-field/20 text-field border-field',
  CANCELLED: 'bg-red-100 text-red-700 border-red-400'
};

export default function OrdersPage() {
  const { status } = useSession();
  const router = useRouter();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if (status === 'authenticated') {
      fetch('/api/orders')
        .then((r) => r.json())
        .then((d) => setOrders(d.orders ?? []))
        .finally(() => setLoading(false));
    }
  }, [status]);

  if (loading) return <p className="mt-6 text-soil/50 text-sm">Loading…</p>;

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">Your orders</h1>
      {orders.length === 0 ? (
        <p className="text-sm text-soil/60 mt-4">No orders yet.</p>
      ) : (
        <div className="space-y-3 mt-4">
          {orders.map((o) => (
            <div key={o.id} className="ledger-card p-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <p className="font-mono text-sm text-soil/70">Order #{o.id.slice(-6)}</p>
                <span className={`stamp text-xs border ${statusColor[o.status]}`}>{o.status}</span>
              </div>
              <div className="mt-2 space-y-1">
                {o.items.map((it: any) => (
                  <p key={it.id} className="text-sm text-field/90">
                    {it.quantity} × {it.product.title} — ₹{((it.unitPrice * it.quantity) / 100).toFixed(2)}
                  </p>
                ))}
              </div>
              <p className="text-sm font-semibold text-field mt-2">Total: ₹{(o.totalAmount / 100).toFixed(2)}</p>
              <p className="text-xs text-soil/50 mt-1">{new Date(o.createdAt).toLocaleString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
