'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import Script from 'next/script';

export default function CheckoutPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (status === 'unauthenticated') {
    router.push('/login');
    return null;
  }

  async function payNow() {
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ shippingAddress: address })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Could not start checkout');

      const options = {
        key: data.keyId,
        amount: data.amount,
        currency: data.currency,
        name: 'Leo Marketplace',
        description: `Order ${data.orderId}`,
        order_id: data.razorpayOrderId,
        handler: async (response: any) => {
          const verifyRes = await fetch('/api/orders/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              orderId: data.orderId,
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature
            })
          });
          if (verifyRes.ok) {
            router.push('/orders');
          } else {
            setError('Payment verification failed. If money was deducted, contact support.');
          }
        },
        prefill: { name: session?.user?.name ?? '', email: session?.user?.email ?? '' },
        theme: { color: '#C98A2C' }
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-6 max-w-md">
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="afterInteractive" />
      <h1 className="font-display text-2xl font-semibold text-field">Checkout</h1>
      <div className="ledger-card p-6 mt-4 space-y-4">
        <label className="text-sm block">
          <span className="block text-soil/70 mb-1">Shipping address</span>
          <textarea
            required
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="border border-soil/30 rounded px-3 py-2 w-full h-24"
            placeholder="House / street, village or city, district, state, PIN code"
          />
        </label>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          onClick={payNow}
          disabled={loading || !address}
          className="w-full px-4 py-3 rounded bg-gold text-field font-medium disabled:opacity-40"
        >
          {loading ? 'Starting payment…' : 'Pay with Razorpay'}
        </button>
        <p className="text-xs text-soil/50">Supports UPI, cards, netbanking and wallets via Razorpay.</p>
      </div>
    </div>
  );
}
