'use client';
import { useRef, useState } from 'react';
import { useLanguage } from '@/lib/LanguageContext';

type Diagnosis = {
  cropGuess: string;
  likelyIssue: string;
  confidence: 'low' | 'medium' | 'high';
  symptoms: string[];
  organicTreatment: string[];
  chemicalTreatment: string[];
  prevention: string[];
  urgency: 'monitor' | 'treat_soon' | 'urgent';
};

const urgencyStyle: Record<string, string> = {
  monitor: 'bg-sky/20 text-sky border-sky',
  treat_soon: 'bg-gold/20 text-gold border-gold',
  urgent: 'bg-red-100 text-red-700 border-red-400'
};

export default function DiseaseDetection() {
  const { t, lang } = useLanguage();
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Diagnosis | null>(null);

  function handleFile(file: File) {
    setResult(null);
    setError(null);
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
  }

  async function scan() {
    if (!preview) return;
    setLoading(true);
    setError(null);
    try {
      const [header, base64] = preview.split(',');
      const mediaType = header.match(/data:(.*);base64/)?.[1] ?? 'image/jpeg';
      const res = await fetch('/api/disease-detection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64, mediaType, language: lang })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Scan failed');
      setResult(data);
    } catch (e: any) {
      setError(e.message ?? 'Something went wrong. Try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-6">
      <h1 className="font-display text-2xl font-semibold text-field">{t('nav_disease')}</h1>
      <div className="ledger-card p-5 mt-4">
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />
        <div className="flex flex-col items-center gap-3">
          {preview ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={preview} alt="Selected crop photo" className="max-h-64 rounded border border-soil/20" />
          ) : (
            <div className="w-full h-40 border-2 border-dashed border-soil/30 rounded flex items-center justify-center text-soil/50 text-sm">
              {t('upload_photo')}
            </div>
          )}
          <div className="flex gap-3">
            <button
              onClick={() => fileRef.current?.click()}
              className="px-4 py-2 rounded border border-field text-field hover:bg-field hover:text-husk transition-colors text-sm"
            >
              {t('upload_photo')}
            </button>
            <button
              onClick={scan}
              disabled={!preview || loading}
              className="px-4 py-2 rounded bg-gold text-field font-medium disabled:opacity-40 text-sm"
            >
              {loading ? t('scanning') : t('scan_now')}
            </button>
          </div>
        </div>
      </div>
      {error && <div className="ledger-card p-4 mt-4 border-red-400 text-red-700 text-sm">{error}</div>}
      {result && (
        <div className="ledger-card p-5 mt-4 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <p className="text-xs text-soil/60 uppercase font-mono">{result.cropGuess}</p>
              <h2 className="font-display text-xl font-semibold text-field">{result.likelyIssue}</h2>
            </div>
            <span className={`stamp text-xs border ${urgencyStyle[result.urgency]}`}>
              {result.urgency.replace('_', ' ')} · {result.confidence} confidence
            </span>
          </div>
          <Section title="Symptoms observed" items={result.symptoms} />
          <Section title="Organic / cultural treatment" items={result.organicTreatment} />
          <Section title="Chemical treatment (use as last resort, follow label)" items={result.chemicalTreatment} />
          <Section title="Prevention next season" items={result.prevention} />
          <p className="text-xs text-soil/60 pt-2 border-t border-soil/10">
            AI-generated guidance — confirm with your local Krishi Vigyan Kendra before large-scale chemical use.
          </p>
        </div>
      )}
    </div>
  );
}

function Section({ title, items }: { title: string; items: string[] }) {
  if (!items?.length) return null;
  return (
    <div>
      <h3 className="font-semibold text-soil text-sm">{title}</h3>
      <ul className="list-disc list-inside text-sm text-field/90 mt-1 space-y-0.5">
        {items.map((it, i) => (
          <li key={i}>{it}</li>
        ))}
      </ul>
    </div>
  );
}
