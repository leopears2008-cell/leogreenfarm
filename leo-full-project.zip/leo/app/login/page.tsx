'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { signIn } from 'next-auth/react';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await signIn('credentials', { email, password, redirect: false });
    setLoading(false);
    if (res?.error) {
      setError('Invalid email or password.');
      return;
    }
    router.push('/marketplace');
    router.refresh();
  }

  return (
    <div className="mt-10 max-w-md mx-auto">
      <h1 className="font-display text-2xl font-semibold text-field">Sign in</h1>
      <form onSubmit={handleSubmit} className="ledger-card p-6 mt-4 space-y-4">
        <label className="text-sm block">
          <span className="block text-soil/70 mb-1">Email</span>
          <input
            type="email"
            value={email}
            required
            onChange={(e) => setEmail(e.target.value)}
            className="border border-soil/30 rounded px-3 py-2 w-full"
          />
        </label>
        <label className="text-sm block">
          <span className="block text-soil/70 mb-1">Password</span>
          <input
            type="password"
            value={password}
            required
            onChange={(e) => setPassword(e.target.value)}
            className="border border-soil/30 rounded px-3 py-2 w-full"
          />
        </label>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full px-4 py-2 rounded bg-gold text-field font-medium disabled:opacity-40"
        >
          {loading ? 'Signing in…' : 'Sign in'}
        </button>
        <p className="text-xs text-soil/60 text-center">
          New here? <a href="/register" className="text-gold hover:underline">Create an account</a>
        </p>
      </form>
    </div>
  );
}
