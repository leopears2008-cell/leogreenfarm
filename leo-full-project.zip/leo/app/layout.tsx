import type { Metadata } from 'next';
import { Fraunces, Work_Sans, IBM_Plex_Mono } from 'next/font/google';
import './globals.css';
import Nav from '@/components/Nav';
import { LanguageProvider } from '@/lib/LanguageContext';
import SessionProviderWrapper from '@/components/SessionProviderWrapper';

const fraunces = Fraunces({ subsets: ['latin'], variable: '--font-fraunces', weight: ['500', '600', '700'] });
const worksans = Work_Sans({ subsets: ['latin'], variable: '--font-worksans', weight: ['400', '500', '600'] });
const plexmono = IBM_Plex_Mono({ subsets: ['latin'], variable: '--font-plexmono', weight: ['400', '500'] });

export const metadata: Metadata = {
  title: 'Leo — Farmer Advisory & Marketplace',
  description: 'AI-powered crop disease detection, weather, irrigation, fertilizer guidance and a farmer-to-buyer marketplace.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${fraunces.variable} ${worksans.variable} ${plexmono.variable} font-body`}>
        <SessionProviderWrapper>
          <LanguageProvider>
            <Nav />
            <main className="max-w-5xl mx-auto px-4 pb-24">{children}</main>
          </LanguageProvider>
        </SessionProviderWrapper>
      </body>
    </html>
  );
}
