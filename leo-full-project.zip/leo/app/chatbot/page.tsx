'use client';
import { useState, useRef, useEffect } from 'react';
import { useLanguage } from '@/lib/LanguageContext';

type Msg = { role: 'user' | 'assistant'; content: string };

export default function ChatbotPage() {
  const { t, lang } = useLanguage();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    const next: Msg[] = [...messages, { role: 'user', content: text }];
    setMessages(next);
    setInput('');
    setLoading(true);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next, lang })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Chat failed');
      setMessages((cur) => [...cur, { role: 'assistant', content: data.reply }]);
    } catch (e: any) {
      setMessages((cur) => [...cur, { role: 'assistant', content: `Error: ${e.message}` }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-6 flex flex-col h-[70vh]">
      <h1 className="font-display text-2xl font-semibold text-field">{t('nav_chat')}</h1>
      <div className="ledger-card flex-1 mt-4 p-4 overflow-y-auto flex flex-col gap-3">
        {messages.length === 0 && (
          <p className="text-sm text-soil/50 m-auto text-center max-w-xs">
            Ask anything about crops, pests, weather-based decisions, irrigation, fertilizer, market prices or government schemes.
          </p>
        )}
        {messages.map((m, i) => (
          <div
            key={i}
            className={`max-w-[85%] px-4 py-2 rounded-lg text-sm ${
              m.role === 'user' ? 'bg-field text-husk self-end rounded-br-none' : 'bg-husk border border-soil/15 text-field self-start rounded-bl-none'
            }`}
          >
            {m.content}
          </div>
        ))}
        {loading && <div className="text-xs text-soil/50 self-start">Leo is typing…</div>}
        <div ref={bottomRef} />
      </div>
      <div className="flex gap-2 mt-3">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
          placeholder={t('ask_placeholder')}
          className="flex-1 border border-soil/30 rounded px-3 py-2 text-sm"
        />
        <button onClick={send} disabled={loading} className="px-4 py-2 rounded bg-gold text-field font-medium text-sm disabled:opacity-40">
          {t('send')}
        </button>
      </div>
    </div>
  );
}
