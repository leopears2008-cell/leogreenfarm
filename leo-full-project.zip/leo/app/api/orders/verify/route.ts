import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { sendOrderNotification } from '@/lib/notify';

export const runtime = 'nodejs';

// POST { orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature }
// Verifies signature, marks order PAID, decrements stock, notifies buyer + seller(s).
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });

  const { orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();

  if (!orderId || !razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return NextResponse.json({ error: 'Missing verification fields' }, { status: 400 });
  }

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { items: { include: { product: true } }, buyer: true }
  });
  if (!order || order.buyerId !== session.user.id) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 });
  }
  if (order.razorpayOrderId !== razorpay_order_id) {
    return NextResponse.json({ error: 'Order mismatch' }, { status: 400 });
  }

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET as string)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expectedSignature !== razorpay_signature) {
    await prisma.order.update({ where: { id: orderId }, data: { status: 'CANCELLED' } });
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 400 });
  }

  await prisma.$transaction([
    prisma.order.update({
      where: { id: orderId },
      data: {
        status: 'PAID',
        razorpayPaymentId: razorpay_payment_id,
        razorpaySignature: razorpay_signature
      }
    }),
    ...order.items.map((item) =>
      prisma.product.update({
        where: { id: item.productId },
        data: { stock: { decrement: item.quantity } }
      })
    )
  ]);

  await sendOrderNotification({
    to: order.buyer.phone,
    message: `Your Leo order #${order.id.slice(-6)} for ₹${(order.totalAmount / 100).toFixed(2)} is confirmed and being prepared.`
  });

  return NextResponse.json({ ok: true });
}
