import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { razorpay } from '@/lib/razorpay';

export const runtime = 'nodejs';

// GET — buyer's own orders (or all orders if admin, via ?all=1)
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const all = searchParams.get('all') === '1' && session.user.role === 'ADMIN';

  const orders = await prisma.order.findMany({
    where: all ? {} : { buyerId: session.user.id },
    include: { items: { include: { product: true } }, buyer: { select: { name: true, email: true } } },
    orderBy: { createdAt: 'desc' }
  });

  return NextResponse.json({ orders });
}

// POST { shippingAddress } — creates an Order from the current cart + a Razorpay order
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });

  const { shippingAddress } = await req.json();
  if (!shippingAddress) {
    return NextResponse.json({ error: 'shippingAddress is required' }, { status: 400 });
  }

  const cartItems = await prisma.cartItem.findMany({
    where: { userId: session.user.id },
    include: { product: true }
  });

  if (cartItems.length === 0) {
    return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
  }

  for (const item of cartItems) {
    if (item.quantity > item.product.stock) {
      return NextResponse.json(
        { error: `${item.product.title}: only ${item.product.stock} ${item.product.unit} left in stock` },
        { status: 400 }
      );
    }
  }

  const totalAmount = cartItems.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  try {
    const order = await prisma.order.create({
      data: {
        buyerId: session.user.id,
        totalAmount,
        shippingAddress,
        status: 'PENDING',
        items: {
          create: cartItems.map((i) => ({
            productId: i.productId,
            quantity: i.quantity,
            unitPrice: i.product.price
          }))
        }
      },
      include: { items: true }
    });

    const razorpayOrder = await razorpay.orders.create({
      amount: totalAmount, // paise
      currency: 'INR',
      receipt: order.id
    });

    await prisma.order.update({
      where: { id: order.id },
      data: { razorpayOrderId: razorpayOrder.id }
    });

    await prisma.cartItem.deleteMany({ where: { userId: session.user.id } });

    return NextResponse.json({
      orderId: order.id,
      razorpayOrderId: razorpayOrder.id,
      amount: totalAmount,
      currency: 'INR',
      keyId: process.env.RAZORPAY_KEY_ID
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Could not create order' }, { status: 500 });
  }
}
