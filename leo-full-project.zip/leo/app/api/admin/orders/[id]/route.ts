import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { sendOrderNotification } from '@/lib/notify';

export const runtime = 'nodejs';

// PATCH { status } — admin updates order status (SHIPPED, DELIVERED, CANCELLED)
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  const { status } = await req.json();
  const allowed = ['PENDING', 'PAID', 'SHIPPED', 'DELIVERED', 'CANCELLED'];
  if (!allowed.includes(status)) {
    return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
  }

  const order = await prisma.order.update({
    where: { id: params.id },
    data: { status },
    include: { buyer: true }
  });

  await sendOrderNotification({
    to: order.buyer.phone,
    message: `Your Leo order #${order.id.slice(-6)} is now ${status.toLowerCase()}.`
  });

  return NextResponse.json(order);
}
