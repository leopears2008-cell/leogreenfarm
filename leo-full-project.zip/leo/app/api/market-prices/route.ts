import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

// Live feed: data.gov.in Agmarknet API (used automatically when DATA_GOV_IN_API_KEY is set).
// Falls back to mock data so the UI always works, e.g. in local dev without a key.
const AGMARKNET_RESOURCE = 'https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070';

const MOCK_PRICES = [
  { commodity: 'Wheat', mandi: 'Karnal, Haryana', minPrice: 2180, maxPrice: 2260, modalPrice: 2220, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Rice (Paddy - Common)', mandi: 'Kurnool, Andhra Pradesh', minPrice: 2020, maxPrice: 2150, modalPrice: 2090, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Cotton', mandi: 'Rajkot, Gujarat', minPrice: 7100, maxPrice: 7450, modalPrice: 7300, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Sugarcane', mandi: 'Meerut, Uttar Pradesh', minPrice: 350, maxPrice: 380, modalPrice: 365, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Groundnut', mandi: 'Junagadh, Gujarat', minPrice: 5800, maxPrice: 6150, modalPrice: 5980, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Mustard', mandi: 'Alwar, Rajasthan', minPrice: 5300, maxPrice: 5550, modalPrice: 5420, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Gram (Chana)', mandi: 'Indore, Madhya Pradesh', minPrice: 5100, maxPrice: 5400, modalPrice: 5250, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Maize', mandi: 'Davangere, Karnataka', minPrice: 1950, maxPrice: 2100, modalPrice: 2020, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Onion', mandi: 'Lasalgaon, Maharashtra', minPrice: 1200, maxPrice: 1850, modalPrice: 1500, unit: 'Rs/quintal', date: '2026-07-10' },
  { commodity: 'Tomato', mandi: 'Kolar, Karnataka', minPrice: 800, maxPrice: 1400, modalPrice: 1100, unit: 'Rs/quintal', date: '2026-07-10' }
];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get('q')?.toLowerCase();
  const apiKey = process.env.DATA_GOV_IN_API_KEY;

  if (apiKey) {
    try {
      const url = new URL(AGMARKNET_RESOURCE);
      url.searchParams.set('api-key', apiKey);
      url.searchParams.set('format', 'json');
      url.searchParams.set('limit', '50');
      if (q) url.searchParams.set('filters[commodity]', q);

      const res = await fetch(url.toString(), { next: { revalidate: 3600 } });
      if (res.ok) {
        const json = await res.json();
        const records = (json.records ?? []).map((r: any) => ({
          commodity: r.commodity,
          mandi: `${r.market}, ${r.state}`,
          minPrice: Number(r.min_price),
          maxPrice: Number(r.max_price),
          modalPrice: Number(r.modal_price),
          unit: 'Rs/quintal',
          date: r.arrival_date
        }));
        if (records.length > 0) {
          return NextResponse.json({ source: 'agmarknet', asOf: new Date().toISOString().slice(0, 10), prices: records });
        }
      }
    } catch {
      // fall through to mock data below
    }
  }

  const data = q ? MOCK_PRICES.filter((p) => p.commodity.toLowerCase().includes(q)) : MOCK_PRICES;
  return NextResponse.json({ source: 'mock', asOf: '2026-07-10', prices: data });
}
