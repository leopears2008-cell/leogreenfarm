import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const { name, email, password, phone, role } = await req.json();

    if (!name || !email || !password) {
      return NextResponse.json({ error: 'name, email and password are required' }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: 'Password must be at least 8 characters' }, { status: 400 });
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      return NextResponse.json({ error: 'An account with this email already exists' }, { status: 409 });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const allowedRoles = ['FARMER', 'BUYER'];
    const safeRole = allowedRoles.includes(role) ? role : 'FARMER';

    const user = await prisma.user.create({
      data: { name, email, passwordHash, phone, role: safeRole }
    });

    return NextResponse.json({ id: user.id, email: user.email, role: user.role });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Registration failed' }, { status: 500 });
  }
}
