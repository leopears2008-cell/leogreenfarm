import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

export const runtime = 'nodejs';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SYSTEM_PROMPT = `You are an agronomy assistant helping smallholder farmers diagnose crop problems from a single photo.
Respond ONLY with strict JSON, no markdown fences, no preamble, matching this shape:
{
  "cropGuess": string,
  "likelyIssue": string,
  "confidence": "low" | "medium" | "high",
  "symptoms": string[],
  "organicTreatment": string[],
  "chemicalTreatment": string[],
  "prevention": string[],
  "urgency": "monitor" | "treat_soon" | "urgent"
}
Keep every array item under 20 words, plain language, no jargon. If the photo is not a usable crop/leaf photo, set cropGuess/likelyIssue accordingly and note it in symptoms.`;

export async function POST(req: NextRequest) {
  try {
    if (!process.env.ANTHROPIC_API_KEY) {
      return NextResponse.json({ error: 'Server is missing ANTHROPIC_API_KEY. Add it to your .env.local file.' }, { status: 500 });
    }
    const { imageBase64, mediaType, language } = await req.json();
    if (!imageBase64 || !mediaType) {
      return NextResponse.json({ error: 'imageBase64 and mediaType are required' }, { status: 400 });
    }

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: mediaType, data: imageBase64 } },
            { type: 'text', text: `Diagnose this crop/leaf photo. Respond in ${language === 'hi' ? 'Hindi' : language === 'ta' ? 'Tamil' : 'English'}.` }
          ]
        }
      ]
    });

    const textBlock = response.content.find((b) => b.type === 'text');
    const raw = textBlock && 'text' in textBlock ? textBlock.text : '{}';
    const cleaned = raw.replace(/```json|```/g, '').trim();
    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      return NextResponse.json({ error: 'Could not parse model response', raw: cleaned }, { status: 502 });
    }
    return NextResponse.json(parsed);
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Unknown error' }, { status: 500 });
  }
}
