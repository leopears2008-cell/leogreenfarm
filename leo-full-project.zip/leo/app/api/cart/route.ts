import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export const runtime = 'nodejs';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });

  const items = await prisma.cartItem.findMany({
    where: { userId: session.user.id },
    include: { product: true },
    orderBy: { createdAt: 'desc' }
  });

  const total = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  return NextResponse.json({ items, total });
}

// POST { productId, quantity } — add or set quantity (quantity <= 0 removes)
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });

  const { productId, quantity } = await req.json();
  if (!productId) return NextResponse.json({ error: 'productId is required' }, { status: 400 });

  const qty = Number(quantity ?? 1);

  if (qty <= 0) {
    await prisma.cartItem.deleteMany({ where: { userId: session.user.id, productId } });
    return NextResponse.json({ ok: true, removed: true });
  }

  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product || !product.active) {
    return NextResponse.json({ error: 'Product not available' }, { status: 404 });
  }
  if (qty > product.stock) {
    return NextResponse.json({ error: `Only ${product.stock} ${product.unit} in stock` }, { status: 400 });
  }

  const item = await prisma.cartItem.upsert({
    where: { userId_productId: { userId: session.user.id, productId } },
    update: { quantity: qty },
    create: { userId: session.user.id, productId, quantity: qty }
  });

  return NextResponse.json(item);
}
