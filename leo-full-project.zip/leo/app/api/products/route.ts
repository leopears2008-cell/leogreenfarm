import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export const runtime = 'nodejs';

// GET /api/products?q=&category=  — public listing
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get('q') ?? undefined;
  const category = searchParams.get('category') ?? undefined;

  const products = await prisma.product.findMany({
    where: {
      active: true,
      ...(q ? { title: { contains: q } } : {}),
      ...(category ? { category } : {})
    },
    include: { seller: { select: { id: true, name: true } } },
    orderBy: { createdAt: 'desc' }
  });

  return NextResponse.json({ products });
}

// POST /api/products — farmer/admin creates a listing
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: 'Sign in required' }, { status: 401 });
  }
  if (!['FARMER', 'ADMIN'].includes(session.user.role)) {
    return NextResponse.json({ error: 'Only farmer accounts can list products' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const { title, description, category, price, unit, stock, imageUrl, imagePublicId } = body;

    if (!title || !description || !category || !price) {
      return NextResponse.json({ error: 'title, description, category and price are required' }, { status: 400 });
    }

    const product = await prisma.product.create({
      data: {
        title,
        description,
        category,
        price: Math.round(Number(price)),
        unit: unit || 'kg',
        stock: Number(stock) || 0,
        imageUrl,
        imagePublicId,
        sellerId: session.user.id
      }
    });

    return NextResponse.json(product, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Could not create listing' }, { status: 500 });
  }
}
