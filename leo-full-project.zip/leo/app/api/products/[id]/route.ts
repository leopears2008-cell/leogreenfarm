import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export const runtime = 'nodejs';

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: {
      seller: { select: { id: true, name: true } },
      reviews: { include: { user: { select: { name: true } } }, orderBy: { createdAt: 'desc' } }
    }
  });
  if (!product) return NextResponse.json({ error: 'Product not found' }, { status: 404 });
  return NextResponse.json(product);
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });

  const product = await prisma.product.findUnique({ where: { id: params.id } });
  if (!product) return NextResponse.json({ error: 'Product not found' }, { status: 404 });

  const isOwner = product.sellerId === session.user.id;
  const isAdmin = session.user.role === 'ADMIN';
  if (!isOwner && !isAdmin) return NextResponse.json({ error: 'Not allowed' }, { status: 403 });

  const body = await req.json();
  const updated = await prisma.product.update({
    where: { id: params.id },
    data: {
      title: body.title ?? product.title,
      description: body.description ?? product.description,
      category: body.category ?? product.category,
      price: body.price !== undefined ? Math.round(Number(body.price)) : product.price,
      unit: body.unit ?? product.unit,
      stock: body.stock !== undefined ? Number(body.stock) : product.stock,
      imageUrl: body.imageUrl ?? product.imageUrl,
      imagePublicId: body.imagePublicId ?? product.imagePublicId,
      active: body.active !== undefined ? Boolean(body.active) : product.active
    }
  });

  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });

  const product = await prisma.product.findUnique({ where: { id: params.id } });
  if (!product) return NextResponse.json({ error: 'Product not found' }, { status: 404 });

  const isOwner = product.sellerId === session.user.id;
  const isAdmin = session.user.role === 'ADMIN';
  if (!isOwner && !isAdmin) return NextResponse.json({ error: 'Not allowed' }, { status: 403 });

  await prisma.product.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
