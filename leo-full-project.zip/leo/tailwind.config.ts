import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        field: '#1F3A2E',
        gold: '#C98A2C',
        husk: '#F6F1E4',
        soil: '#5C4433',
        sky: '#6FA8C4'
      },
      fontFamily: {
        display: ['var(--font-fraunces)', 'Georgia', 'serif'],
        body: ['var(--font-worksans)', 'Noto Sans', 'Noto Sans Tamil', 'Noto Sans Devanagari', 'sans-serif'],
        mono: ['var(--font-plexmono)', 'ui-monospace', 'monospace']
      },
      backgroundImage: {
        ledger: 'repeating-linear-gradient(to bottom, transparent, transparent 27px, rgba(92,68,51,0.12) 28px)'
      }
    }
  },
  plugins: []
};
export default config;
