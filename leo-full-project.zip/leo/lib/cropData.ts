export type CropWindow = {
  crop: string;
  season: 'Kharif' | 'Rabi' | 'Zaid';
  sowMonth: number;
  sowSpan: number;
  harvestMonth: number;
  harvestSpan: number;
  waterNeed: 'Low' | 'Medium' | 'High';
};

export const cropCalendar: CropWindow[] = [
  { crop: 'Rice (Paddy)', season: 'Kharif', sowMonth: 6, sowSpan: 1, harvestMonth: 10, harvestSpan: 1, waterNeed: 'High' },
  { crop: 'Cotton', season: 'Kharif', sowMonth: 5, sowSpan: 1, harvestMonth: 11, harvestSpan: 2, waterNeed: 'Medium' },
  { crop: 'Sugarcane', season: 'Kharif', sowMonth: 3, sowSpan: 2, harvestMonth: 1, harvestSpan: 2, waterNeed: 'High' },
  { crop: 'Maize (Kharif)', season: 'Kharif', sowMonth: 6, sowSpan: 1, harvestMonth: 9, harvestSpan: 1, waterNeed: 'Medium' },
  { crop: 'Groundnut', season: 'Kharif', sowMonth: 6, sowSpan: 1, harvestMonth: 10, harvestSpan: 1, waterNeed: 'Medium' },
  { crop: 'Wheat', season: 'Rabi', sowMonth: 11, sowSpan: 1, harvestMonth: 3, harvestSpan: 1, waterNeed: 'Medium' },
  { crop: 'Mustard', season: 'Rabi', sowMonth: 10, sowSpan: 1, harvestMonth: 2, harvestSpan: 1, waterNeed: 'Low' },
  { crop: 'Gram (Chana)', season: 'Rabi', sowMonth: 10, sowSpan: 1, harvestMonth: 2, harvestSpan: 1, waterNeed: 'Low' },
  { crop: 'Sunflower (Rabi)', season: 'Rabi', sowMonth: 11, sowSpan: 1, harvestMonth: 3, harvestSpan: 1, waterNeed: 'Medium' },
  { crop: 'Watermelon', season: 'Zaid', sowMonth: 2, sowSpan: 1, harvestMonth: 5, harvestSpan: 1, waterNeed: 'Medium' },
  { crop: 'Moong (Summer)', season: 'Zaid', sowMonth: 3, sowSpan: 1, harvestMonth: 5, harvestSpan: 1, waterNeed: 'Low' },
  { crop: 'Vegetables (Cucumber/Gourd)', season: 'Zaid', sowMonth: 3, sowSpan: 1, harvestMonth: 6, harvestSpan: 1, waterNeed: 'Medium' }
];

export type GrowthStage = 'Sowing / Basal' | 'Vegetative' | 'Flowering' | 'Fruiting / Grain fill';
export type FertilizerPlan = { stage: GrowthStage; npkAdvice: string; note: string };

export const fertilizerRules: Record<string, FertilizerPlan[]> = {
  'Rice (Paddy)': [
    { stage: 'Sowing / Basal', npkAdvice: 'Basal dose: full P & K + 1/3 N (approx. DAP 50kg/acre + MOP 20kg/acre + Urea 35kg/acre)', note: 'Apply at transplanting.' },
    { stage: 'Vegetative', npkAdvice: 'Top-dress 1/3 N (Urea ~35kg/acre) at active tillering (18–22 days after transplanting)', note: 'Keep field flooded during this stage.' },
    { stage: 'Flowering', npkAdvice: 'Final 1/3 N (Urea ~35kg/acre) at panicle initiation', note: 'Skip if leaf colour chart shows adequate greenness.' },
    { stage: 'Fruiting / Grain fill', npkAdvice: 'Foliar 2% DAP spray if grain filling looks weak', note: 'Optional, only for visible deficiency.' }
  ],
  Wheat: [
    { stage: 'Sowing / Basal', npkAdvice: 'Basal: full P & K + 1/2 N (DAP 50kg/acre + MOP 20kg/acre + Urea 45kg/acre)', note: 'Apply at sowing.' },
    { stage: 'Vegetative', npkAdvice: 'Top-dress remaining 1/2 N at first irrigation (crown root initiation, ~21 days)', note: 'Do not delay past tillering.' },
    { stage: 'Flowering', npkAdvice: 'No additional N needed unless deficiency symptoms appear', note: 'Watch for yellowing lower leaves.' },
    { stage: 'Fruiting / Grain fill', npkAdvice: 'Optional foliar 2% urea spray at milk stage for grain weight', note: 'Improves grain filling in stressed crops.' }
  ],
  Cotton: [
    { stage: 'Sowing / Basal', npkAdvice: 'Basal: full P & K + 1/4 N (DAP 40kg/acre + MOP 20kg/acre + Urea 20kg/acre)', note: 'Apply at sowing.' },
    { stage: 'Vegetative', npkAdvice: 'Split N doses at 30 and 60 days (Urea ~25kg/acre each)', note: 'Coincide with square formation.' },
    { stage: 'Flowering', npkAdvice: 'Balanced N-K at flowering/boll formation, add micronutrient (boron) spray', note: 'Boron improves boll retention.' },
    { stage: 'Fruiting / Grain fill', npkAdvice: 'Foliar 1% MOP spray during boll development', note: 'Improves fibre quality and boll weight.' }
  ],
  Sugarcane: [
    { stage: 'Sowing / Basal', npkAdvice: 'Basal: full P & K + 1/3 N (DAP 60kg/acre + MOP 40kg/acre + Urea 45kg/acre)', note: 'Apply at planting.' },
    { stage: 'Vegetative', npkAdvice: '1/3 N at tillering (45–60 days)', note: 'Earth-up after application.' },
    { stage: 'Flowering', npkAdvice: 'Final 1/3 N at grand growth phase (90–120 days)', note: 'Ensure adequate irrigation.' },
    { stage: 'Fruiting / Grain fill', npkAdvice: 'No N after 120 days — switch to K-only if lodging risk', note: 'Late N delays ripening.' }
  ],
  Default: [
    { stage: 'Sowing / Basal', npkAdvice: 'Apply full phosphorus & potash with 1/3–1/2 of total nitrogen as basal dose', note: 'Localize using Soil Health Card results.' },
    { stage: 'Vegetative', npkAdvice: 'Top-dress remaining nitrogen in 1–2 splits during active growth', note: 'Split doses reduce nitrogen loss.' },
    { stage: 'Flowering', npkAdvice: 'Ensure potash availability; consider micronutrient foliar spray', note: 'Watch for deficiency symptoms.' },
    { stage: 'Fruiting / Grain fill', npkAdvice: 'Avoid further nitrogen; support with potash if needed', note: 'Excess late N can delay maturity.' }
  ]
};

export function getFertilizerPlan(crop: string): FertilizerPlan[] {
  return fertilizerRules[crop] ?? fertilizerRules.Default;
}
