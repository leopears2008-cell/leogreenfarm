export type Lang = 'en' | 'hi' | 'ta';

export const translations: Record<Lang, Record<string, string>> = {
  en: {
    appName: 'Leo',
    tagline: 'Your field, your data, your decisions.',
    nav_home: 'Home',
    nav_disease: 'Disease Scan',
    nav_weather: 'Weather & Irrigation',
    nav_fertilizer: 'Fertilizer',
    nav_calendar: 'Crop Calendar',
    nav_market: 'Market Prices',
    nav_schemes: 'Govt. Schemes',
    nav_chat: 'Ask Leo',
    nav_marketplace: 'Marketplace',
    upload_photo: 'Upload a leaf or crop photo',
    scan_now: 'Scan for disease',
    scanning: 'Analysing photo…',
    get_weather: 'Get weather for my location',
    ask_placeholder: 'Ask about your crop, pest, weather, or a scheme…',
    send: 'Send'
  },
  hi: {
    appName: 'लियो',
    tagline: 'आपका खेत, आपका डेटा, आपके फैसले।',
    nav_home: 'होम',
    nav_disease: 'रोग जांच',
    nav_weather: 'मौसम और सिंचाई',
    nav_fertilizer: 'उर्वरक',
    nav_calendar: 'फसल कैलेंडर',
    nav_market: 'मंडी भाव',
    nav_schemes: 'सरकारी योजनाएं',
    nav_chat: 'लियो से पूछें',
    nav_marketplace: 'बाज़ार',
    upload_photo: 'पत्ती या फसल की फोटो अपलोड करें',
    scan_now: 'रोग के लिए स्कैन करें',
    scanning: 'फोटो का विश्लेषण हो रहा है…',
    get_weather: 'अपने स्थान का मौसम प्राप्त करें',
    ask_placeholder: 'अपनी फसल, कीट, मौसम या योजना के बारे में पूछें…',
    send: 'भेजें'
  },
  ta: {
    appName: 'லியோ',
    tagline: 'உங்கள் வயல், உங்கள் தரவு, உங்கள் முடிவுகள்.',
    nav_home: 'முகப்பு',
    nav_disease: 'நோய் ஸ்கேன்',
    nav_weather: 'வானிலை & நீர்ப்பாசனம்',
    nav_fertilizer: 'உரம்',
    nav_calendar: 'பயிர் காலண்டர்',
    nav_market: 'சந்தை விலைகள்',
    nav_schemes: 'அரசு திட்டங்கள்',
    nav_chat: 'லியோவிடம் கேளுங்கள்',
    nav_marketplace: 'சந்தை',
    upload_photo: 'ஒரு இலை அல்லது பயிர் புகைப்படத்தை பதிவேற்றவும்',
    scan_now: 'நோய்க்காக ஸ்கேன் செய்யவும்',
    scanning: 'புகைப்படம் பகுப்பாய்வு செய்யப்படுகிறது…',
    get_weather: 'எனது இருப்பிடத்திற்கான வானிலையைப் பெறவும்',
    ask_placeholder: 'உங்கள் பயிர், பூச்சி, வானிலை அல்லது திட்டம் பற்றி கேளுங்கள்…',
    send: 'அனுப்பு'
  }
};

export function t(lang: Lang, key: string): string {
  return translations[lang]?.[key] ?? translations.en[key] ?? key;
}
