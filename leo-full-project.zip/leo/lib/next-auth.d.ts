import 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      role: 'FARMER' | 'BUYER' | 'ADMIN';
      name?: string | null;
      email?: string | null;
    };
  }
  interface User {
    id: string;
    role: 'FARMER' | 'BUYER' | 'ADMIN';
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string;
    role: 'FARMER' | 'BUYER' | 'ADMIN';
  }
}
