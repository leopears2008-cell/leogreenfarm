// Sends order/status notifications via Twilio SMS or WhatsApp.
// Requires TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER (e.g. 'whatsapp:+14155238886').
// If not configured, this silently logs instead of throwing, so local dev works without Twilio.

export async function sendOrderNotification({ to, message }: { to?: string | null; message: string }) {
  if (!to) return;

  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_FROM_NUMBER;

  if (!sid || !token || !from) {
    console.log(`[notify:disabled] Would send to ${to}: ${message}`);
    return;
  }

  try {
    const client = require('twilio')(sid, token);
    await client.messages.create({
      body: message,
      from,
      to: from.startsWith('whatsapp:') ? `whatsapp:${to}` : to
    });
  } catch (err) {
    console.error('Notification failed:', err);
  }
}
