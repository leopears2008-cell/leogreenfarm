'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession, signOut } from 'next-auth/react';
import { useLanguage } from '@/lib/LanguageContext';
import { Lang } from '@/lib/translations';

const links = [
  { href: '/', key: 'nav_home' },
  { href: '/disease-detection', key: 'nav_disease' },
  { href: '/weather', key: 'nav_weather' },
  { href: '/fertilizer', key: 'nav_fertilizer' },
  { href: '/crop-calendar', key: 'nav_calendar' },
  { href: '/market-prices', key: 'nav_market' },
  { href: '/schemes', key: 'nav_schemes' },
  { href: '/chatbot', key: 'nav_chat' },
  { href: '/marketplace', key: 'nav_marketplace' }
];

export default function Nav() {
  const { lang, setLang, t } = useLanguage();
  const pathname = usePathname();
  const { data: session } = useSession();
  const role = (session?.user as any)?.role;

  return (
    <header className="bg-field text-husk border-b-4 border-gold">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-4 flex-wrap">
        <Link href="/" className="font-display text-2xl font-semibold tracking-tight">
          {t('appName')}
        </Link>
        <div className="flex items-center gap-3 text-sm">
          <div className="flex items-center gap-1">
            {(['en', 'hi', 'ta'] as Lang[]).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                aria-pressed={lang === l}
                className={`px-2 py-1 rounded font-mono uppercase ${
                  lang === l ? 'bg-gold text-field' : 'text-husk/70 hover:text-husk'
                }`}
              >
                {l}
              </button>
            ))}
          </div>
          {session ? (
            <div className="flex items-center gap-2">
              <Link href="/cart" className="text-husk/80 hover:text-husk">Cart</Link>
              <Link href="/orders" className="text-husk/80 hover:text-husk">Orders</Link>
              {role === 'ADMIN' && <Link href="/admin" className="text-husk/80 hover:text-husk">Admin</Link>}
              <button onClick={() => signOut({ callbackUrl: '/' })} className="text-husk/80 hover:text-husk">
                Sign out
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link href="/login" className="text-husk/80 hover:text-husk">Sign in</Link>
              <Link href="/register" className="px-2 py-1 rounded bg-gold text-field font-medium">Sign up</Link>
            </div>
          )}
        </div>
      </div>
      <nav className="max-w-5xl mx-auto px-4 pb-2 flex flex-wrap gap-x-4 gap-y-1 text-sm">
        {links.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className={`py-1 border-b-2 ${
              pathname === l.href ? 'border-gold text-gold' : 'border-transparent text-husk/80 hover:text-husk'
            }`}
          >
            {t(l.key)}
          </Link>
        ))}
      </nav>
    </header>
  );
}
