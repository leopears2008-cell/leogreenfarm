# Leo — Farmer Advisory + Marketplace Platform

A Next.js 14 app with two halves:

**Advisory tools** (unchanged from the original build):
- AI crop disease detection from photos (Claude vision)
- Weather forecast + auto-generated irrigation advice (Open-Meteo)
- Fertilizer (NPK) suggestions by crop and growth stage
- Crop calendar (Kharif / Rabi / Zaid)
- Market price lookup — live via data.gov.in Agmarknet when a key is set, mock otherwise
- Government scheme info
- Multilingual chatbot — English, Hindi, Tamil (Claude)

**Marketplace** (new):
- MySQL database via Prisma
- Email/password auth (NextAuth, JWT sessions, FARMER / BUYER / ADMIN roles)
- Farmers list products with Cloudinary-hosted photos
- Buyers browse, add to cart, checkout
- Razorpay payments (UPI/cards/netbanking), signature-verified server-side
- Order history for buyers
- Admin dashboard: revenue/orders/products overview, order status management, product moderation
- SMS/WhatsApp order notifications via Twilio (optional — logs to console if not configured)

## 1. Install

```bash
npm install
```

## 2. Configure environment

```bash
cp .env.example .env.local
```

Fill in `.env.local`:

| Variable | Required for | Notes |
|---|---|---|
| `ANTHROPIC_API_KEY` | Disease Scan, Ask Leo | https://console.anthropic.com |
| `DATABASE_URL` | Everything marketplace-related | MySQL connection string |
| `NEXTAUTH_SECRET` | Auth | `openssl rand -base64 32` |
| `NEXTAUTH_URL` | Auth | e.g. `http://localhost:3000` |
| `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` | Checkout | https://dashboard.razorpay.com (test mode keys to start) |
| `CLOUDINARY_CLOUD_NAME` / `CLOUDINARY_API_KEY` / `CLOUDINARY_API_SECRET` | Product photo upload | https://cloudinary.com console |
| `TWILIO_*` | Order SMS/WhatsApp | Optional — without it, notifications just log to the server console |
| `DATA_GOV_IN_API_KEY` | Live mandi prices | Optional — falls back to demo data |

## 3. Set up the database

Create a MySQL database, then:

```bash
npx prisma migrate dev --name init
```

This creates all tables (users, products, cart items, orders, order items, reviews).

Optionally seed an admin account:

```bash
npm install -D tsx
npx tsx prisma/seed.ts
```

This creates `admin@leo.app` / `ChangeMe123!` (override with `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` env vars). **Change this password after first login** — there's no in-app password-reset flow yet, so update it directly in the database or re-run the seed against a fresh row if needed.

## 4. Run

```bash
npm run dev
```

Open http://localhost:3000

## Where things live

| Feature | Page | API route |
|---|---|---|
| Register / login | `/register`, `/login` | `/api/auth/register`, `/api/auth/[...nextauth]` |
| Marketplace browse | `/marketplace` | `/api/products` |
| Product detail | `/marketplace/[id]` | `/api/products/[id]` |
| List a product (farmer) | `/marketplace/sell` | `/api/products` (POST), `/api/upload/sign` |
| Cart | `/cart` | `/api/cart` |
| Checkout (Razorpay) | `/checkout` | `/api/orders`, `/api/orders/verify` |
| Order history | `/orders` | `/api/orders` |
| Admin dashboard | `/admin`, `/admin/orders`, `/admin/products` | `/api/admin/orders/[id]`, `/api/products/[id]` |
| Disease detection | `/disease-detection` | `/api/disease-detection` |
| Weather + irrigation | `/weather` | `/api/weather` |
| Market prices | `/market-prices` | `/api/market-prices` |
| Chatbot | `/chatbot` | `/api/chat` |

## Payment flow

1. Buyer checks out → `POST /api/orders` creates a `PENDING` order in MySQL and a matching Razorpay order.
2. Razorpay Checkout.js opens client-side (test mode: use card `4111 1111 1111 1111`, any future expiry/CVV, or any UPI VPA ending `@razorpay` in test mode).
3. On success, `POST /api/orders/verify` recomputes the HMAC signature server-side, marks the order `PAID`, and decrements stock in a transaction.
4. Admin can move orders through `SHIPPED` → `DELIVERED` from `/admin/orders`; each transition fires a notification.

For production, also add a Razorpay **webhook** endpoint (`payment.captured` / `order.paid` events) as a safety net in case the client-side `handler` callback never fires (e.g. browser closed mid-payment) — verify the `X-Razorpay-Signature` header against `RAZORPAY_WEBHOOK_SECRET` before trusting it.

## Notes on scaling this further

- **Auth**: currently email/password only. Add phone+OTP via an SMS provider if most farmers prefer that.
- **Search**: product search is a simple `LIKE` query; move to a proper search index (Meilisearch/Algolia) at scale.
- **Reviews**: schema and API-level support exist; add a review-submission UI on the order-history page once an order is `DELIVERED`.
- **Images**: uploads go straight to Cloudinary from the browser using a signed, time-limited signature — the API secret never reaches the client.
