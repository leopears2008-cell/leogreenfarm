// Creates a default admin account for the dashboard.
// Run with: npx tsx prisma/seed.ts   (or: npm install -D tsx, then npm run db:seed)
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const email = process.env.SEED_ADMIN_EMAIL || 'admin@leo.app';
  const password = process.env.SEED_ADMIN_PASSWORD || 'ChangeMe123!';

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    console.log(`Admin already exists: ${email}`);
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);
  await prisma.user.create({
    data: { name: 'Leo Admin', email, passwordHash, role: 'ADMIN' }
  });

  console.log(`Created admin user: ${email} / ${password}`);
  console.log('Sign in, then change this password immediately.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
